---
name: '🐞 Bug Report'
about: Report an error in this repository
title: 'Fix: xxx'
labels: bug
assignees: ''
---

<!-- Please describe the error in as much detail as possible so that we can fix it quickly -->
